# CHANGELOG — versie 1.7 (november 2026)

### ✨ Nieuw
- **Mini-rooster voor de beheerder** bovenin Rooster: maandkalender met stipjes bij dagen met diensten; tik op een dag om alleen die dag te zien.
- **Statistieken**: grafiek *Uren deze maand* per medewerker op de beheerder-Home (met vorige/volgende maand, totaal, gemiddelde en aantal diensten).
- **Grotere profielfoto** bij Beheer → Uitbetaling en Medewerkers; nieuwe betaalkaart met bedrag en *Uitbetaald*-knop rechts.
- **Feestdagen-thema** (`holiday.js`): sneeuw + lichtslinger met Kerst, pepernoten (Sinterklaas), confetti (Oud & nieuw, Koningsdag), vleermuizen (Halloween), eitjes (Pasen). Automatisch op datum; dev kan forceren of uitzetten; iedereen kan het zelf uitzetten (Profiel → Weergave). Ook op de loginpagina.
- **Taalschakelaar NL/EN** (Profiel → Weergave; `i18n.js` + `i18n-en.js`). Vertaalt live; wat nog niet in het woordenboek staat blijft Nederlands (`MHVI18N.missing()` in de console toont wat ontbreekt).
- **Nieuwe loginpagina**: donker, logo gecentreerd, afgeronde velden, drie snelle-inlogtegels (biometrie / QR / snelcode), taalknop.
- **Sluitchecklist opnieuw**: kaart op Home voor de sluitdienst (ook voor beheerders), direct afvinken zonder popup-flikkering, voortgangsring, naam + tijd per taak, *Alles gedaan*-melding. Beheer → Instellingen heeft nu een lijst-editor (taken toevoegen/verwijderen).
- **Beschikbaarheid opnieuw**: raster van 14 dagen (groen = je kunt), *Opslaan*, sectie *Afwezigheid* met periodes en *Afwezig melden*. Beheerder ziet per dag wie niet kan + aankomende afwezigheid.
- **Meldingen-instellingen** (Profiel → App → Meldingen, of het tandwiel bij Meldingen): dag van tevoren, een uur ervoor, na afloop van je dienst, push, e-mail. De herinneringen, push en e-mail volgen deze keuzes.
- **Stijl zwart/wit (“Clean”)**: dev kiest globaal bij Beheer → Instellingen → Uiterlijk tussen Klassiek (blauw/geel, standaard) en Clean (zwart/wit). Het MHVwork-logo blijft altijd hetzelfde.

### 🎨 v1.8 — verfijning
- **Loginpagina opnieuw**: vlak zwart, één kolom, topbalk met logo + taalkeuze, duidelijke labels, gelijke velden, geen verlopen of gloed. De login-logica is niet aangeraakt.
- **Clean-stijl rustiger**: neutrale kaarten en tegels, dunne randen, uitlijnbare staafjes, badges als dunne outline, geen gekleurde vlakken.

### 🔧 Techniek
- Nieuwe bestanden: `holiday.js`, `i18n.js`, `i18n-en.js`. Nieuwe iconen `globe` en `sparkles` in `icons.js`.
- Nieuwe velden: `users/{uid}.notifPrefs`, `users/{uid}.lang`, `settings/general.skin`, `settings/general.holiday`. Geen wijziging in `firestore.rules` nodig.

---

# CHANGELOG — versie 1.6 (oktober 2026)

Volledige beschrijving: zie [V1.6.md](./V1.6.md).

### ✨ Nieuw
- **Open diensten**: beheerder maakt een dienst aan zonder iemand toe te wijzen en vraagt wie wil (aantal plekken; "jij kiest" of "direct toewijzen"). Op ieders homepage staat een kaart *Open dienst* met dag, tijd, aantal plekjes en de knop **Geef je op**. Beheerder wijst toe via *Dienst bewerken*.
- **Bar-scherm**: klein knopje onderaan de homepage opent de idle-modus, en het scherm blijft aan zolang die draait (Screen Wake Lock).
- **QR-sessies in het Logboek** (dev): wie is er via QR ingelogd, met een knop *Overal uitloggen* per account.
- **Inloggen met vingerafdruk of gezicht** (per toestel, aan te zetten in Profiel → Snelle toegang).
- **QR schermvullend tonen**.
- **Open dienst telt af**: elke aanmelding haalt één vrij plekje af (2 plekjes, 1 aanmelding = "1 plekje vrij", daarna "Vol"); de regels dwingen dat af.
- **Pinpas: gewone downloadknop** (PDF direct, of PNG) naast *Opslaan in galerij*.

### 🗑️ Verwijderd
- De knop/instelling **Niet-urgente e-mails** en alle logica daarachter: alle mails worden nu altijd verstuurd.

### 🔒 Beveiliging
- **Gat gedicht**: wie zelf een account aanmaakte, kon zichzelf een profiel met rol `admin` of `software` geven. Zelf-registratie werkt nu alleen nog met een geldige uitnodiging en precies de rol/e-mail/loon uit die uitnodiging. Het eerste admin-account maak je voortaan in de Firebase Console aan.

### ⚠️ Bij deze update
- `firestore.rules` opnieuw publiceren en **direct testen of registreren met een uitnodiging nog werkt**. Geen nieuwe Firebase-instellingen nodig.

### ℹ️ Niet mogelijk op Spark
- Apple/Google Wallet-pas (vraagt een server om te ondertekenen). Uitleg en alternatieven staan in V1.6.md.

---

# CHANGELOG — versie 1.5 "snelle toegang" (oktober 2026)

Volledige beschrijving: zie [V1.5.md](./V1.5.md).

### ✨ Nieuw
- **Snelcode-login** (knop *Snelcode* op de inlogpagina) met een rijk snel-overzicht (`fast.html`): aftelring voor je dienst, collega's op dezelfde dienst, komende diensten, thuiswedstrijden (vandaag, komende 7 dagen, "tijdens je dienst"-label) en berichten sturen met snelle zinnen. Niets onthouden, sluit na 5 minuten.
- **Verplichte snelcode** voor elk account, met knop voor een veilige gegenereerde code.
- **Persoonlijke QR** per account: inloggen in je volledige account. Opslaan in galerij, A4-kaartje printen of **pinpasformaat** (85,6 × 54 mm, voor + achter, PDF of PNG).
- **QR scannen** op de inlogpagina (opent de camera; ook gewoon de camera-app werkt).
- **QR vernieuwen** door eigenaar, beheerder (medewerkers) of dev (iedereen): oude QR direct ongeldig, mail naar de getroffene. Dev kan een snelcode resetten.
- **Wit thema geoptimaliseerd**: alle tekst ≥ 5:1 contrast, gele tekst op wit donkergeel, knoppen met rand en schaduw, blauwe actieve tab, zichtbare invoervelden en kaartranden.
- **Eerste login: één popup tegelijk**: (installatie →) rondleiding → teamkeuze → snelcode (+ QR).
- Rustigere knoppen (*Snelcode* / *QR scannen*) in de stijl van de rest van de inlogpagina.

### ⚠️ Verplichte stappen bij deze update
1. Firebase Console → Authentication → Sign-in method → **Anonymous** inschakelen (gratis, Spark).
2. `firestore.rules` opnieuw publiceren.
3. Uploaden: `app.html`, `index.html`, `firestore.rules`, en de nieuwe `fast.html`, `qr.js`, `jsqr.js`, `jsqr.LICENSE.txt`, `V1.5.md`.

### ℹ️ Goed om te weten
- Geen Blaze-plan nodig: alles werkt op Spark, de beveiliging zit in de Firestore-regels.
- Een geschorst account verliest direct ook zijn QR-/snelcode-toegang.
- De snelcode is geen wachtwoord: wie hem raadt kan jouw dienst zien en namens jou berichten sturen, meer niet. Gebruik liefst "Genereer een veilige code".
- De 4-pogingen-blokkade (15 min) zit in de app per toestel, niet op de server (Spark kent geen servercode): voldoende voor deze data, maar omzeilbaar door iemand die gericht aanvalt.

---

# CHANGELOG — update oktober 2026 (deel 6, "widget")

### ✨ Nieuw — het dichtstbijzijnde dat een PWA bij een widget kan komen
Een écht homescreen-widget bestaat technisch niet voor PWA's (niet op Android, niet op iOS — dat is een browserbeperking, geen keuze). Dit is de praktische vervanging, in drie delen:
- **App-shortcuts** (Android: lang drukken op het app-icoon): "Volgende dienst", "Beschikbaar melden", "Rooster" — direct de juiste plek in de app, zonder eerst Home te laden.
- **Cijferbadge op het app-icoon**: laat zien hoeveel diensten je vandaag hebt (1 of meer), zonder de app te hoeven openen. Verdwijnt vanzelf als je geen dienst hebt.
- **"Volgende dienst"-snelweergave**: een piepklein, razendsnel schermpje — datum, tijd, met wie, en (indien van toepassing) de wedstrijd-waarschuwing. Geen homepage-opbouw, direct het enige wat je op dat moment wil weten.

### ⚠️ Let op
- Shortcuts werken alleen als de app is "toegevoegd aan beginscherm" (geïnstalleerd) én alleen op Android/Chrome — iOS ondersteunt long-press-shortcuts voor web-apps niet.
- De badge werkt in de meeste Android-browsers en in Safari op iOS 16.4+, maar niet overal.

---

# CHANGELOG — update oktober 2026 (deel 5, bugfix)

### 🐞 Opgelost
- **Foutieve bewering in de importuitleg en in de console-melding zelf.** Zowel de tutorial als de melding op de MHV-website beweerden dat het resultaat automatisch op je klembord stond, puur op basis van of de klembord-functie van de browser *bestaat* — niet of het kopiëren ook echt *gelukt* was. In de praktijk blokkeren browsers dit vaak vanuit de Console. De melding checkt nu het echte resultaat, en de uitleg wijst voortaan expliciet naar de handmatige "Kopiëren"-knop die bij het resultaat in de Console staat (stap 5 is hierop aangepast) als terugval.

---

# CHANGELOG — update oktober 2026 (deel 4, bugfix)

### 🐞 Opgelost
- **Screenshots in de nieuwe importuitleg bleven leeg.** De afbeeldingen misten het `data:image/jpeg;base64,`-voorvoegsel, waardoor de browser ze niet kon laden. Gefixt — alle 5 screenshots zijn gecontroleerd en laden nu correct.

# CHANGELOG — update oktober 2026 (deel 3, bugfixes)

### 🐞 Opgelost
- **Uitklapbaar dienstadvies en "bekijk alle wedstrijden" deden niets.** De functie die de knop nodig had (`refreshMatchesUI`) was per ongeluk niet globaal beschikbaar binnen de app — een klik gaf een foutmelding in de console en er gebeurde zichtbaar niets. Dit verklaart vermoedelijk ook de klacht dat een blok soms later ineens "vanzelf" opschuift: de klik werkte pas zodra er toevallig ergens anders in de app al een herlaadmoment plaatsvond. We hebben de hele app nagelopen op dit type fout (een knop die een functie aanroept die niet bestaat) — er waren geen andere plekken met hetzelfde probleem.
- **Leesbevestiging in de privéchat werkte alleen bij het openen van een gesprek.** Bleef het gesprek open terwijl er een nieuw bericht binnenkwam, dan werd dat niet meteen als "Gezien" gemarkeerd. Dit werkt nu ook terwijl het gesprek al open staat.

### ✨ Nieuw
- **Aankondiging bewerken.** Wie een aankondiging mag verwijderen, mag 'm nu ook aanpassen (titel, tekst, zichtbaarheid, afbeelding, bijlages). Een beheerder kan nog steeds geen aankondiging van een dev bewerken of verwijderen.
- **Stap-voor-stap uitleg bij het importeren van wedstrijden**, met echte schermafbeeldingen, direct bij het importpaneel (knop "Hoe werkt importeren?"). Met de aanbeveling dit op een laptop/desktop te doen, omdat rechtsklikken en de Developer Tools op een telefoon anders werken.

### ⚠️ Na het updaten
- Publiceer de nieuwe `firestore.rules` opnieuw (de regel voor het bewerken van aankondigingen is aangescherpt, gelijk aan de regel voor verwijderen).

---

# CHANGELOG — update oktober 2026 (deel 2)

### ✅ Opgelost
- **Wedstrijden dubbel bij herimporteren.** Elke wedstrijd krijgt nu een vaste sleutel (datum + thuisteam + uitteam) in plaats van het wisselende LISA-record-id. Een herhaalde import of sync werkt dezelfde wedstrijd bij. Bestaande dubbelingen van vóór deze update worden bij de eerstvolgende import automatisch opgeruimd.

### ✨ Nieuw
- **Dienstadvies en wedstrijdenlijst ingeklapt** — namen te veel ruimte in op Home/Rooster en bij Instellingen.
- **Gastaccount definitief maken** (dev): verwijdert de vervaldatum, wordt een gewoon account.
- **Zoeken in de groepschat** + een apart **archief van vastgepinde berichten**.
- **Leesbevestiging ("Gezien") en "aan het typen…"** in de privéchat.
- **Kalender vernieuwd**: eigen stijl per stip (dienst/wedstrijd), rustigere maand-animatie, legenda.
- **Eigen team per account** (verplicht bij eerste login, ook voor bestaande accounts, wijzigbaar in Profiel). Bij het samenstellen van een dienst waarschuwt de app als iemand die dag een eigen wedstrijd heeft, met het advies dit in de Lisa-app te checken.
- **Wedstrijd-importlog (alleen dev)**, met een knop om een hele import in één keer ongedaan te maken.
- **Offline-indicator** + berichten (groepschat en privé) die automatisch alsnog verstuurd worden zodra er weer verbinding is.

### ⚠️ Na het updaten
- Publiceer de nieuwe `firestore.rules` opnieuw (regels voor `matchImportLog` en het `typing`-veld bij privéberichten).
- Zet ook de nieuwe `sync-lisa-matches.mjs` in de GitHub Actions-workflow, anders blijft de automatische sync het oude, dubbel-gevoelige ID gebruiken.
- Eerste keer inloggen na deze update vraagt iedereen (behalve dev) om een team te kiezen — dat gebeurt automatisch, geen actie nodig.

---

# CHANGELOG — update oktober 2026

### ✅ Opgelost
- **Groepschat stotterde na het versturen** — de hele lijst werd bij elke update opnieuw getekend, met bij elk bericht de intro-animatie en een sprong naar beneden. Nu animeert alleen een écht nieuw bericht, en blijft je scrollpositie staan als je omhoog scrolt.

### ✨ Nieuw
- **Dev-beheer met tabs** (Accounts · Gasten · Wedstrijden · Berichten · Instellingen), net als bij beheerder. Logboek en Aankondigingen blijven eigen tabbladen.
- **Dev kan wedstrijden importeren en invoeren**; bij de laatste import staat wie het deed (of "automatische sync").
- **Wedstrijdkaart** toont alleen tijd, logo's, wie tegen wie en waar.
- **Dienstadvies** voor beheerders (Rooster en Home) op basis van wedstrijden, met "Maak dienst aan" (voorinvuller). Regels staan bovenaan als `ADVICE_RULES` in `app.html`.
- **Tijdelijke accounts moeten door dev worden goedgekeurd**; dev beheert ze in de tab Gasten. Beheerders kunnen een gastaccount niet meer zelf verlengen (ook afgedwongen in de Firestore-regels).
- **Foto's en bijlagen in privéberichten** (max 700 KB, nieuwe collectie `dmFiles`).
- **Aankondigingen**: werkbalk met live voorbeeld (vet, schuin, onderstreept, doorgehaald, markeren, kop, lijst, link). Foto mee in de e-mail als miniatuur.
- **Eigen achtergrond** — lokaal op het toestel, kost geen database-opslag.

### ⚠️ Na het updaten
- Publiceer de nieuwe `firestore.rules` (regels voor `dmFiles` en gastaccount-velden).
- Voor de foto in de e-mail: voeg `{{{image_html}}}` toe aan je EmailJS-aankondigingstemplate (zie HANDLEIDING).

---

# CHANGELOG — update augustus 2026

Puntsgewijs, gekoppeld aan de oorspronkelijke lijst.

### ✅ Opgelost
- **Announcement-knop "insufficient permissions"** — de `announcements`-collectie had helemaal
  geen Firestore-regel, dus werd elke schrijfactie geblokkeerd. Regel toegevoegd.
- **Wachtwoord-reset link ongeldig** — het oude systeem maakte nooit een écht tijdelijk
  wachtwoord aan. Volledig vervangen door Firebase's eigen, beveiligde reset-flow.
  *(check Stap 3 in HANDLEIDING.md — authorized domain!)*
- **Rooster opent niet op "Alles"** — twee losstaande tab-sets deelden per ongeluk dezelfde
  variabele. Losgekoppeld; rooster opent nu standaard op "Alles".
- **Beheerders konden geen dev-rol toewijzen** — het gekozen rol-veld werd nooit opgeslagen bij
  het aanmaken van een uitnodiging. Gefixt.
- **@tag in chat stuurt alleen nog een pushmelding**, geen e-mail meer.
- **Pin-bug in chat** — het vastgepinde bericht stond bovenin de scrollende berichtenlijst en
  verdween dus bij scrollen. Nu een eigen vaste balk, altijd zichtbaar.
- **Uitbetaalknop uit de chat gehaald**; foto's versturen toegevoegd (incl. slepen/droppen).
- **Export-agendaknop werkte niet (vooral op mobiel/PWA)** — iOS/Android PWA's blokkeren
  soms stille blob-downloads. Nu eerst een poging via de Deel-functie (Web Share API), met
  download als fallback op desktop. Ook toegevoegd aan de dagweergave (stond er eerder niet).
- **Kalender "loopt vast"** — defensieve null-checks/try-catch toegevoegd rond het
  kalender-rendering, zodat één foutje niet alles blokkeert.
- **Promo.html paste niet op mobiel** — de vaste 1280×720-pixelinhoud werd nooit echt
  geschaald. Nu een correcte, universele schaal-fix (werkt in portret én landschap).
- **Help-knop** stuurt niet meer naar de promo-pagina, maar toont per pagina een korte,
  relevante uitleg (wat het is, wat je ermee kan, tips).
- **Beheerder zag zelf nooit aankondigingen op de homepage** — ontbrak, nu toegevoegd.

### ✨ Nieuw
- **Privéberichten (DM)** tussen medewerker en beheerder/dev, los van de groepschat.
- **Meldingen is nu een volledige pagina** (i.p.v. een dropdown-paneeltje), met tabs
  "Systeem" (aankondigingen/tags/uitbetalingen — visueel anders) en "Berichten" (de DM's).
- **Bevestigingsreminder-systeem**: melding direct na afloop van een onbevestigde dienst,
  tweede herinnering na een instelbaar aantal uren (standaard 30, aan te passen onder
  Beheer → Instellingen), en de oorspronkelijke tijd is daarna niet meer door de beheerder
  aan te passen — status toont "Geweest, onbevestigd".
- **Dashboard medewerker**: "Goedgekeurd" en "Uitbetaald" nu apart zichtbaar i.p.v. samengevoegd.
- **PWA-installatiepopup** direct na het aanmaken van een account, met een vinkje bij Profiel
  zodra de app daadwerkelijk geïnstalleerd is.
- **Dev: speciale aankondigingen** — eigen (rode) kleur, verschijnen als in-app pop-up, en
  sturen meteen push + e-mail naar de doelgroep.
- **Dienstnotities met foto** — beheerders kunnen bij een dienst een notitie + afbeelding
  toevoegen; medewerkers zien dit in hun rooster en krijgen een melding.
- **Meer animaties**: tabs, knoppen, chatbubbels, tabbalk, modals.
- **Beveiliging aangescherpt**: uitnodigingen kunnen niet meer door willekeurige bezoekers
  herschreven worden vóór registratie, wachtwoord-reset-systeem grondig herzien.

### 🔧 Optioneel, vereist eigen actie (zie HANDLEIDING.md)
- **Eigen e-mailtemplate per soort mail** — structuur staat klaar, jij vult de EmailJS-
  template-ID's in.
- **Gmail SMTP i.p.v. EmailJS** — code staat klaar in `functions/`, vereist Firebase Blaze-plan
  en handmatige deploy (kan niet vanuit deze sessie gedaan worden).

### ⚠️ Nog niet aangepast / bekende beperking
- De exacte 30-uurs reminder is **client-side getimed** (checkt zodra iemand de app opent),
  niet een exacte server-cronjob — op GitHub Pages zonder Cloud Functions kan dat niet
  nauwkeuriger. In de praktijk hebben beheerders/medewerkers de app regelmatig open, dus komt
  dit er in de praktijk dicht bij, maar het is geen harde garantie op de minuut.

## 🆕 Update 2 — bugfixes op gemelde problemen + nieuwe features

### 🐛 Bevestigde bugs (root cause gevonden, niet alleen symptoombestrijding)
- **"Eigen afwezigheid niet zichtbaar/verwijderbaar"** — de Firestore-query combineerde een filter met een sortering op een ander veld, wat een composite index vereiste die er nooit was. Zonder foutafhandeling faalde dit stil (geen data, geen foutmelding). Query vereenvoudigd (client-side sorteren) + foutafhandeling toegevoegd.
- **"Account met zelfde e-mail kan niet opnieuw aangemaakt worden"** — "verwijderen" in het dev-paneel wiste alleen het Firestore-profiel, nooit het Firebase Auth-account (dat kan technisch niet vanuit de app zelf). Duidelijke waarschuwing + handmatige oplossing toegevoegd (Firebase Console → Authentication), en een echte Cloud Function klaargezet voor als je dit ooit automatisch wil laten verlopen.
- **Agenda-export "nog steeds kapot"** — extra, specifiek voor iOS betrouwbaardere aanpak toegevoegd (`data:`-URI, een bekend werkend patroon in PWA's op Safari).

### ✨ Nieuw
- Automatisch groen vinkje wanneer een hele dienst klaar én iedereen uitbetaald is.
- Beheerder kan een dienst aanmaken zónder direct iemand toe te wijzen (oranje status), met automatische herinnering aan beheerders naarmate de datum nadert.
- Pushmeldingen uitgebreid: dag ervoor, 1 uur ervoor, direct na afloop ("hoe was je dienst?"), en de bestaande 30-uurs vervolgherinnering.
- E-mail/push-keuze bij het versturen van een privébericht via Meldingen; afzender staat duidelijk in titel + e-mail.
- E-mailvoorkeuren per medewerker: niet-urgente mails (bijv. vervallen dienst, notitie) zijn uit te zetten bij Profiel. Wachtwoord-mails en persoonlijke berichten van beheerder/dev blijven altijd binnenkomen.
- Profielfoto's voor iedereen (opgeslagen als gecomprimeerde afbeelding in het profiel zelf — geen Firebase Storage/Blaze-upgrade nodig), zichtbaar in chat en accountoverzicht.
- Excel-export van diensten over een gekozen periode: medewerkers als rijen, datums als kolommen, kruisje + tijden in de cellen.
- Geverifieerd-vinkje is nu een echt icoon (geen emoji meer) en door de dev toe te wijzen/intrekken bij elk account, niet meer alleen automatisch voor dev-accounts.
- "Bericht naar beheerder"-knoppen bij Profiel verwijderd (overbodig sinds Meldingen dit al kan). Meldingen-icoon nu geel.

## 🆕 Update 3 — dev als volwaardig eigen accounttype

- **Dev heeft nu een écht eigen navigatiestructuur**, net als beheerder z'n eigen tabs heeft — niet langer alles verzameld in één "Dev"-tab met subtabjes. Drie aparte pagina's onderin de tabbalk: **Beheer** (accounts + uitzending), **Aankondiging**, **Logboek**. Plus Chat, Meldingen en Profiel, die alle rollen delen.
- **Dev heeft geen Home-tab** — een dev is geen medewerker en start nu direct op de Beheer-pagina.
- Help-uitleg (het "?"-icoon) bijgewerkt met de juiste tekst per nieuwe dev-pagina.

## 🚨 Hotfix — "geen enkele knop werkt na inloggen"

Kritieke fout: bij het opsplitsen van het dev-paneel in aparte pagina's bleef er één verwijzing
staan naar de oude, inmiddels verwijderde functie `renderDev`. Daardoor crashte het script
meteen bij het opstarten, vóórdat alle knoppen aan hun functies gekoppeld konden worden —
inloggen werkte nog (apart stukje code), maar daarna reageerde niets meer. Verwijderd en
getest met een volledige runtime-simulatie (niet alleen een syntax-check) om zeker te zijn
dat alle 77 functies weer correct gebonden worden.

## 🆕 Update 4 — bugfixes op je laatste meldingen

- **Privébericht sturen "hele veld is 1 knop"** — root cause: kwetsbare, dubbel-geëscapete quotes in een onclick-attribuut met de naam van de ontvanger erin, wat bij bepaalde tekens de HTML-parsing brak. Volledig herschreven naar `data-uid`-attributen + losse click-listeners per rij (robuuster, geen escaping-risico meer).
- **Zwart scherm bij klikken op een chatfoto** — `window.open()` op een `data:`-URI faalt vaak stil in een PWA. Vervangen door een echte in-app lightbox (overal waar op een foto geklikt kan worden: chat, dienstnotities).
- **Logboek uitgebreider en overzichtelijker**: per-gebruiker samenvattingskaartjes (aantal logins, eerste/laatste keer) bovenaan, aanklikbaar om de tijdlijn te filteren, plus een "Exporteer naar Excel"-knop.
- **Tab- en meldingen-icoon animeren nu** bij het wisselen van pagina (kleine "pop"-animatie).
- **Geschorst account krijgt een eigen pagina** direct na inloggen, met de reden die de beheerder/dev bij het schorsen kan invullen — i.p.v. een simpele foutmelding op de inlogpagina.
- **README volledig herschreven**: overzichtelijker, met badges, inhoudsopgave, projectstructuur, en een licentie-sectie (inclusief de externe bibliotheken die MHVwork gebruikt en hún licenties).

## 🆕 Update 5 — bugfixes ronde 2

- **Animaties die na 1x stopten** → vervangen door de Web Animations API, speelt nu altijd opnieuw af.
- **Privébericht/aankondiging-acties "deden niets"** → root cause: geen foutafhandeling rond Firestore-aanroepen in `openDMThread`, `sendDM` en `deleteAnnouncement`. Als zo'n aanroep faalt (bv. rules nog niet bijgewerkt), gebeurde er he-le-maal niets zichtbaars. Nu tonen alle drie een duidelijke foutmelding met reden.
- **Niet-beschikbare medewerkers toch toevoegbaar bij het bewerken van een dienst** → `openEditShift` checkte beschikbaarheid niet (in tegenstelling tot bij aanmaken). Gefixt, met behoud van reeds-toegewezen medewerkers.
- **E-mail-keuze bij élke aankondiging** (niet alleen speciale).
- **Geen emoji meer op de schorsingspagina** — nu een SVG-icoon.
- **Beheerders konden dev-aankondigingen niet verwijderen** — zelfde silent-failure patroon als hierboven, nu met foutmelding. Dev's eigen Aankondiging-pagina toont nu ook alle bestaande aankondigingen (kon voorheen niet).
- **"Tygo" hernoemd naar "Dev"** in de hardcoded dev-bypass. *Let op: als er al een bestaand account met de naam "Tygo (Dev)" in je database staat, pas die zelf even aan via Beheer → Accounts → ✏ Rol/gegevens — nieuwe accounts krijgen nu automatisch "Dev".*
- **Datum aanpasbaar bij het bewerken van een afwezigheidsmelding** (kon voorheen alleen de reden).
- **Logboek opvragen via het gesprek met de dev**: beheerder klikt "Vraag logboek op" in de chat met de dev → dev kiest welke gebruikers in de export mogen en keurt goed → aanvrager krijgt een downloadknop in hetzelfde gesprek.
- **Agenda-export grondig herzien**: na onderzoek bleek elke losse "trick" (blob-download, Share API, `data:`-URI) op zich onbetrouwbaar — Apple blokkeert het dynamisch openen van .ics-bestanden in sommige gevallen, en Android-browsers hebben bekende bugs met .ics-afhandeling. Nu een keuze-scherm (zoals Eventbrite/Meetup): "Google Agenda" (opent direct, werkt universeel) of "Apple Agenda / Outlook" (.ics-download, nu ook met de verplichte `DTSTAMP`-regel die eerder ontbrak — sommige agenda-apps weigerden het bestand zonder die regel volledig).

## 🆕 Update 6 — twee kritieke fixes + verdere verbeteringen

### 🚨 Kritiek (verklaart meerdere terugkerende klachten)
- **Agenda-export "werkte nog steeds niet"**: de knoppen verwezen rechtstreeks naar `allShifts` middenin een `onclick=""`-attribuut. Zulke attributen draaien in de globale scope, terwijl `allShifts` module-scoped is — dus onzichtbaar daarbuiten. Dit gaf altijd een `ReferenceError`, op alle apparaten, meteen bij het klikken. Gefixt door alleen het ID mee te geven.
- **Privébericht "werkt nog steeds niet"**: eindelijk de échte oorzaak gevonden dankzij jouw screenshot — een subtiele fout in de Firestore-regel crashte bij het *allereerste* bericht naar iemand nieuws (vóór het gesprek bestaat), en Firestore behandelt zo'n crash als een blokkade. **Dit vereist opnieuw dat je de bijgewerkte `firestore.rules` publiceert in de Firebase Console — zonder die stap blijft dit stuk.**

### ✨ Verder deze ronde
- Beheerders kunnen **geen** dev-aankondigingen meer verwijderen (teruggedraaid, was per ongeluk andersom gefixt) — zowel in de app als hard in de Firestore-regels.
- Geverifieerd-vinkje en profielfoto tonen nu op veel meer plekken (roosterlijsten, dienstenoverzicht, privéberichten-lijst, logboek), niet alleen chat/profiel.
- Ruilverzoek: als iemand interesse toont, wordt het **originele** bericht in de chat nu ook duidelijk visueel bijgewerkt (gele rand + "✓ interesse"-label), niet alleen een nieuw apart berichtje.
- Verborgen easter egg: tik 7x snel op het logo 🍺
- Feestdagen-thema (kerst, oud & nieuw, Koningsdag, Halloween, Pasen): klein feestelijk accent bij het logo + eenmalige felicitatie in de app. *Het daadwerkelijke beginscherm-icoon van de PWA kan helaas niet dynamisch wisselen — dat is een technische beperking van hoe app-iconen werken, geen keuze.*
- E-mailvoorkeuren-sectie verduidelijkt: dit gaat alleen over e-mail, in-app pushmeldingen beheer je bij Meldingen.

## 🆕 Update 7

### 🚨 Belangrijke architectuurfix
- **Pushmeldingen "werkten niet helemaal"**: geanalyseerd en uitgelegd — de bestaande "push" toonde
  alleen een melding lokaal bij wie de actie uitvoerde, nooit bij de daadwerkelijke ontvanger op
  een ander apparaat. Dat kan alleen via een echte pushserver. Firebase Cloud Messaging-infrastructuur
  toegevoegd (client-registratie + Cloud Function + service worker) — **optioneel te activeren, zie
  Stap 6 in HANDLEIDING.md**. Zonder die stap blijft alles werken zoals nu (lokale meldingen).

### ✨ Nieuw
- **Privéberichten zijn nu een volledige pagina** i.p.v. een pop-up, met terugknop, precies zoals de groepschat.
- Privéberichten zijn nu **altijd alleen een pushmelding** — geen e-mail-keuze meer.
- **Geweest + volledig uitbetaalde diensten zijn niet meer te bewerken of verwijderen** — tonen een "🔒 Afgehandeld"-label.
- **Custom laadanimatie** i.p.v. een generieke spinner (het logo dat zachtjes ademt + een laadbalk).
- **Easter egg verbeterd**: elke tik op het logo telt nu mee (bijgehouden), en bij 7x snel achter elkaar ontgrendel je een **geheim thema**: elke dag een nieuwe foto van NASA's "Astronomy Picture of the Day" als achtergrond, te kiezen bij Profiel → Thema.
- **Nieuw thema: "Liquid Glass"** 🫧 — een kleurrijk, vervagend glaseffect-thema, gewoon te kiezen naast licht/donker/systeem (systeem blijft de standaard).

## 🔐 Update 8 — beveiligingsaudit (P0 + belangrijkste P1)

Naar aanleiding van een grondige externe security-review. Dit was de belangrijkste update tot nu toe.

### 🚨 P0 — direct opgelost
- **`seed-admin.html` verwijderd** — dit bestand bevatte letterlijk een e-mailadres + wachtwoord in de broncode, zichtbaar voor iedereen die de (publieke) GitHub-repo opent. Vervangen door een veilige, handmatige eerste-admin-procedure via Firebase Console zelf (zie HANDLEIDING.md, stap 1.7) — daar staat nergens een wachtwoord in code.
- **Hardcoded admin/dev-bypass verwijderd** uit `app.html`. Rollen komen nu uitsluitend uit het Firestore-document van de gebruiker zelf, zoals het hoort — geen tweede, gevaarlijke autorisatielaag op basis van een e-mailadres-string meer.
- **`tempPw`-restcode verwijderd** uit `register.html` — dit veld werd nergens meer daadwerkelijk gezet, maar de kwetsbare logica (incl. een rauwe REST-call naar Google's identity-API) stond er nog wel, wat een onnodig risico was. Vereenvoudigd naar een duidelijke foutmelding.
- **Invite-uitnodigingen herontworpen**: `list` (de hele collectie in één keer opvragen) stond open voor **iedereen op internet, zonder in te loggen** — dat betekende dat elke openstaande uitnodiging (naam, e-mail, loon) uit te lezen was zonder enige toegang. Nu: het ophalen van één specifieke, unieke link blijft mogelijk (dat is hoe uitnodigingslinks werken), maar de hele lijst doorzoeken kan alleen nog door beheerder/dev.

### 🔒 P1 — belangrijkste punt opgelost
- **`/users`-collectie was volledig leesbaar voor elke ingelogde medewerker** — inclusief e-mailadres en loon van alle collega's. Volledig herontworpen: een medewerker kan nu alleen nog het **eigen** volledige profiel lezen, plus het volledige profiel van beheerders/dev (nodig om ze te kunnen mailen bij een ruilverzoek of privébericht). Voor het herkennen van collega's in chat/rooster (naam, rol, foto, vinkje) bestaat nu een aparte, bewust minimale `publicProfiles`-collectie zonder e-mail of loon.

### ✅ Overige P1-punten
- **Verlopen/gebruikte uitnodiging opnieuw bruikbaar**: al afgedekt — de regel controleert `!resource.data.used`, dus een reeds-gebruikte link kan niet opnieuw geclaimd worden.
- **Medewerker kan zichzelf niet admin/dev maken**: al afgedekt én dit keer extra getest via de regel-logica — het `role`-veld zit in de lijst met velden die een gebruiker nooit zelf mag wijzigen.
- **Medewerker kan geen betalingen van anderen lezen**: de `payments`-collectie was al beperkt tot beheerder/dev; ongewijzigd, klopt al.
- Live testen met een echt medewerker-, beheerder- en dev-account kan ik niet vanuit hier (ik heb geen toegang tot jouw Firebase-project) — de bovenstaande punten zijn gecontroleerd via de regel-logica zelf, maar een handmatige eindcontrole met drie echte testaccounts blijft een goed idee vóór je live gaat.

### 📌 P2 — voor later (nog niet gedaan, bewust)
CSP/security headers, dependency-audit, rate limiting, Firebase App Check, geautomatiseerde rule-tests. Dit zijn allemaal zinvolle vervolgstappen maar minder urgent dan de P0/P1-punten hierboven — laat het weten als je hier ook mee verder wil.
